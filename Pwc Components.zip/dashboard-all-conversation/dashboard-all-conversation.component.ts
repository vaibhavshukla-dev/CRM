import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard-all-conversation',
  templateUrl: './dashboard-all-conversation.component.html',
  styleUrls: ['./dashboard-all-conversation.component.css']
})
export class DashboardAllConversationComponent implements OnInit {

  single: any[] = [
    {
      "name": "Loan Origination",
      "value": 894
    },
    {
      "name": "Service Request",
      "value": 500
    },
    {
      "name": "Book a Ride",
      "value": 730
    },
    {
      "name": "Appointment Booking",
      "value": 350
    },
    {
      "name": "Enquiries",
      "value": 720
    },
    {
      "name": "TeleMedicine",
      "value": 900
    },
    {
      "name": "Doctor Request",
      "value": 900
    },

  ];
  view: any[] = [500, 400];
  legend: boolean = true;
  legendPosition: string = 'below';

  colorScheme = {
    domain: ['#556ee6', '#f1b44c', '#34c38f', '#ff5722', '#61d264', '#8bc34a', '#009688', '#7f7f7f', 'ff5722']
  };

  constructor() { }

  ngOnInit() {
  }

}
