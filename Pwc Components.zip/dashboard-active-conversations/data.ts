export const single = [
  {
    "name": "Active Contacts",
    "value": 894
  }
];